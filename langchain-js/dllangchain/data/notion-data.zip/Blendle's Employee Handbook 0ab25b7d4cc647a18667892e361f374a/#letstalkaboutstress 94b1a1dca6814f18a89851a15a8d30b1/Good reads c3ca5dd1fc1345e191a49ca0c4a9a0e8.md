# Good reads

# Good items used as source

---

[Help Your Team Manage Stress, Anxiety, and Burnout](https://hbr.org/2016/01/help-your-team-manage-stress-anxiety-and-burnout?utm_source=All+Poynter+Subscribers&utm_campaign=375ceb2697-EMAIL_CAMPAIGN_2017_04_12&utm_medium=email&utm_term=0_5372046825-375ceb2697-257900805)

[Burnout Self-Test: Are You at Risk?](https://www.mindtools.com/pages/article/newTCS_08.htm)

[Diversify Your Identity](https://markmanson.net/diversify-your-identity)

[Recovering from Burnout](https://kierantie.com/a/burnout/)

[Practical Frameworks for Beating Burnout](http://firstround.com/review/practical-frameworks-for-beating-burnout/)

[From Rats in Cages to Primates in Paradise - The Scientific Story of Stress in Society](https://medium.com/basic-income/human-park-a-mammals-guide-to-stress-free-living-17f6cab007b3)

# Interesting related reads

---

[Tijd voor de pauzeknop](https://blendle.com/i/eos-wetenschap/tijd-voor-de-pauzeknop/bnl-eos056-20171026-89e43bf8b68?sharer=eyJ2ZXJzaW9uIjoiMSIsInVpZCI6InJvbGFuZGdyb290ZW5ib2VyIiwiaXRlbV9pZCI6ImJubC1lb3MwNTYtMjAxNzEwMjYtODllNDNiZjhiNjgifQ%3D%3D)

[Strategieën tegen stress](https://blendle.com/i/eos-wetenschap/strategieen-tegen-stress/bnl-eos056-20171026-8480d9a47b8?sharer=eyJ2ZXJzaW9uIjoiMSIsInVpZCI6InJvbGFuZGdyb290ZW5ib2VyIiwiaXRlbV9pZCI6ImJubC1lb3MwNTYtMjAxNzEwMjYtODQ4MGQ5YTQ3YjgifQ%3D%3D)

[Go with the Flow](https://blendle.com/i/eos-wetenschap/go-with-the-flow/bnl-eos056-20171026-353b94fdffd?sharer=eyJ2ZXJzaW9uIjoiMSIsInVpZCI6InJvbGFuZGdyb290ZW5ib2VyIiwiaXRlbV9pZCI6ImJubC1lb3MwNTYtMjAxNzEwMjYtMzUzYjk0ZmRmZmQifQ%3D%3D)

[Help Your Team Achieve Work-Life Balance - Even When You Can't](https://hbr.org/2017/08/help-your-team-achieve-work-life-balance-even-when-you-cant)

[The Science Of Success](http://www.huffingtonpost.com/don-joseph-goewey-/stress-success_b_5652874.html)

[Can't Get No Satisfaction](http://nymag.com/news/features/24757/)

[How I Reduced Stress, Increased Productivity, and Made Myself Happy Again](https://betterhumans.coach.me/how-i-reduced-stress-increased-productivity-and-made-myself-happy-again-7be3cdedd28f)

[]()

[How to avoid startup stress & founder burnout - The Startup - Medium](https://medium.com/@mitchellharper/how-to-avoid-startup-stress-founder-burnout-121c705fb2ff)

[(2/5) Hoe word je een minder gestreste werknemer?](https://www.youtube.com/watch?v=Npm_7wd_aZ8)

[Trickle-down workaholism in startups - Signal v. Noise](https://m.signalvnoise.com/trickle-down-workaholism-in-startups-a90ceac76426)

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2)