# #letstalkaboutstress

Let’s talk about stress. Too much stress. 

We know this can be a topic.

So let’s get this conversation going. 

[Intro: two things you should know](#letstalkaboutstress%2094b1a1dca6814f18a89851a15a8d30b1/Intro%20two%20things%20you%20should%20know%20c2199837d9aa4f1082e0831016336d84.md)

[What is stress](#letstalkaboutstress%2094b1a1dca6814f18a89851a15a8d30b1/What%20is%20stress%208e411ee990224947b6766232b7e576b9.md)

[When is there too much stress?](#letstalkaboutstress%2094b1a1dca6814f18a89851a15a8d30b1/When%20is%20there%20too%20much%20stress%20d39842254995417bb7f3cb7aa59165d2.md)

[What can I do](#letstalkaboutstress%2094b1a1dca6814f18a89851a15a8d30b1/What%20can%20I%20do%20169e241ceb574982b518341b9bbce123.md)

[What can Blendle do?](#letstalkaboutstress%2094b1a1dca6814f18a89851a15a8d30b1/What%20can%20Blendle%20do%20c26442c8396f4bcca9229e6be98acdfa.md)

[Good reads](#letstalkaboutstress%2094b1a1dca6814f18a89851a15a8d30b1/Good%20reads%20c3ca5dd1fc1345e191a49ca0c4a9a0e8.md)

Go to **#letstalkaboutstress** on slack to chat about this topic

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).